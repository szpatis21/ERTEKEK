import { showAlert } from "/both/alert.js";
import { passwordPanelContent, addPasswordValidationLogic } from "/both/passwordChange.js";

function applyStyles(element, styles = {}) {
    Object.assign(element.style, styles);
    return element;
}

function createElement(tag, options = {}, ...children) {
    const element = document.createElement(tag);

    if (options.id) element.id = options.id;
    if (options.className) element.className = options.className;
    if (options.text !== undefined) element.textContent = String(options.text);
    if (options.htmlFor) element.htmlFor = options.htmlFor;
    if (options.type) element.type = options.type;
    if (options.value !== undefined) element.value = String(options.value);
    if (options.disabled !== undefined) element.disabled = Boolean(options.disabled);
    if (options.styles) applyStyles(element, options.styles);
    if (options.attrs) {
        Object.entries(options.attrs).forEach(([key, value]) => {
            if (value === false || value === null || value === undefined) return;
            element.setAttribute(key, value === true ? '' : String(value));
        });
    }

    children.flat().forEach(child => {
        if (child === null || child === undefined) return;
        element.append(child);
    });

    return element;
}

function clearAndAppend(parent, ...children) {
    parent.replaceChildren(...children.filter(child => child !== null && child !== undefined));
}

function textNode(value) {
    return document.createTextNode(String(value ?? ''));
}

function createOverlay(id = '') {
    const overlay = createElement('div', { id });
    applyStyles(overlay, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(0,0,0,0.7)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: '99999'
    });
    return overlay;
}

function createModalBox() {
    const modalBox = createElement('div');
    applyStyles(modalBox, {
        backgroundColor: '#fff',
        padding: '25px',
        borderRadius: '8px',
        maxWidth: '500px',
        width: '90%',
        boxShadow: '0 4px 20px rgba(0,0,0,0.3)',
        color: '#333'
    });
    return modalBox;
}

function appendBoldText(parent, value) {
    parent.appendChild(createElement('b', { text: value }));
}

function createWarningBox(borderColor, backgroundColor) {
    return createElement('div', {
        styles: {
            marginBottom: '15px',
            padding: '10px',
            background: backgroundColor,
            borderLeft: `4px solid ${borderColor}`,
            textAlign: 'left'
        }
    });
}

function createSafePasswordFragment(html) {
    const allowedTags = new Set([
        'div', 'span', 'p', 'br', 'strong', 'b', 'em', 'i', 'small',
        'label', 'input', 'button', 'form', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4'
    ]);

    const allowedAttrs = new Set([
        'id', 'class', 'type', 'name', 'placeholder', 'value', 'autocomplete',
        'required', 'minlength', 'maxlength', 'min', 'max', 'step', 'for',
        'aria-label', 'aria-describedby', 'rows', 'cols', 'disabled'
    ]);

    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    const fragment = document.createDocumentFragment();

    const sanitizeNode = (node) => {
        if (node.nodeType === Node.TEXT_NODE) {
            return document.createTextNode(node.textContent || '');
        }

        if (node.nodeType !== Node.ELEMENT_NODE) {
            return document.createDocumentFragment();
        }

        const tag = node.tagName.toLowerCase();
        if (!allowedTags.has(tag)) {
            const safeFragment = document.createDocumentFragment();
            node.childNodes.forEach(child => {
                safeFragment.appendChild(sanitizeNode(child));
            });
            return safeFragment;
        }

        const safeElement = document.createElement(tag);
        Array.from(node.attributes).forEach(attr => {
            const name = attr.name.toLowerCase();
            const value = attr.value || '';

            if (name.startsWith('on')) return;
            if (!allowedAttrs.has(name)) return;
            if ((name === 'id' || name === 'class') && /[<>"'`]/.test(value)) return;

            safeElement.setAttribute(name, value);
        });

        node.childNodes.forEach(child => {
            safeElement.appendChild(sanitizeNode(child));
        });

        return safeElement;
    };

    doc.body.childNodes.forEach(node => {
        fragment.appendChild(sanitizeNode(node));
    });

    return fragment;
}

function createInfoPanelContent(cardId) {
    const fragment = document.createDocumentFragment();

    if (cardId === 'changepass') {
        fragment.appendChild(createSafePasswordFragment(passwordPanelContent));
        return fragment;
    }

    if (cardId === 'remove') {
        fragment.append(
            createElement('p', {
                text: 'Biztosan visszavonja a hozzájárulását? Ez a művelet nem vonható vissza.'
            }),
            createElement('button', { text: 'Visszavonás' })
        );
        return fragment;
    }

    if (cardId === 'plussj') {
        fragment.append(
            createElement('p', {
                text: 'Jelezze az intézményi adminisztrátornak, milyen szerepkört szeretne kérni. Jelenlegi szerepköreit jobb oldali sávban láthatja.'
            }),
            createElement('textarea'),
            createElement('button', { text: 'Küldés' })
        );
        return fragment;
    }

    if (cardId === 'deleteacc') {
        const loader = createElement('div', { id: 'delete-loader' },
            createElement('p', { text: 'Fiók információk ellenőrzése...' }),
            createElement('div', { className: 'spinner' })
        );

        const content = createElement('div', {
            id: 'delete-content',
            styles: { display: 'none' }
        });

        fragment.append(loader, content);
        return fragment;
    }

    return fragment;
}

function createBlockingAdminModal(modules) {
    const overlay = createOverlay();
    const modalBox = createModalBox();

    const content = createElement('div', {
        styles: {
            textAlign: 'left',
            padding: '15px',
            fontFamily: 'sans-serif',
            color: '#333'
        }
    });

    content.append(
        createElement('h3', {
            text: 'Jogosultság átadása szükséges!',
            styles: {
                color: 'red',
                textAlign: 'center',
                marginBottom: '15px'
            }
        }),
        createElement('p', {},
            textNode('Ön az '),
            createElement('b', { text: 'egyedüli Adminisztrátor' }),
            textNode(' a következő modulokban, ezért jelenleg nem törölheti a fiókját:')
        )
    );

    const list = createElement('ul', {
        styles: {
            marginTop: '10px',
            marginBottom: '15px',
            paddingLeft: '20px',
            color: 'red'
        }
    });

    modules.forEach(module => {
        const li = createElement('li');
        li.appendChild(createElement('b', { text: module.leiras || module.nev || 'Ismeretlen modul' }));
        list.appendChild(li);
    });

    const instruction = createElement('p', {
        text: 'A felső menüsávban az "átjelentkezésre" kattintva váltson szerepkört, ha kell szakmai anyagot, és az Adminisztrátori felületen adjon adminisztrátori jogot egy kollégájának a profil törlése előtt!'
    });

    const closeButton = createElement('button', {
        id: 'btnElzavaroBezaras',
        text: 'Bezárás',
        styles: {
            marginTop: '20px',
            width: '100%',
            backgroundColor: '#555',
            color: 'white',
            padding: '12px',
            border: 'none',
            cursor: 'pointer',
            borderRadius: '5px',
            fontWeight: 'bold',
            fontSize: '1rem'
        }
    });

    closeButton.addEventListener('click', () => overlay.remove());

    content.append(list, instruction, closeButton);
    modalBox.appendChild(content);
    overlay.appendChild(modalBox);
    document.body.appendChild(overlay);
}

function createSharedUsersWarning(sharedUsers) {
    const box = createWarningBox('orange', 'rgba(255,165,0,0.1)');
    const title = createElement('b', {
        text: 'Az alábbi megosztott értékelései fognak végleg eltűnni a kollégáitól:'
    });

    const list = createElement('ul', {
        styles: {
            marginTop: '5px',
            paddingLeft: '20px'
        }
    });

    sharedUsers.forEach(user => {
        const li = createElement('li');

        const modulLeiras = user.modul_leiras ? `[${user.modul_leiras}]` : '[Ismeretlen modul]';
        const teljesNev = user.vizsgalt_nev
            ? `${user.kitoltes_neve || 'Névtelen értékelés'} (${user.vizsgalt_nev})`
            : (user.kitoltes_neve || 'Névtelen értékelés');

        li.append(
            textNode(`${modulLeiras} `),
            createElement('b', { text: teljesNev }),
            textNode(` (Kolléga: ${user.vez || 'Ismeretlen kolléga'})`)
        );

        list.appendChild(li);
    });

    box.append(title, list);
    return box;
}

function createDeleteWarningModal(data) {
    const overlay = createOverlay('customDeleteModal');
    const modalBox = createModalBox();

    const content = createElement('div', {
        styles: {
            textAlign: 'center',
            fontFamily: 'sans-serif'
        }
    });

    content.append(
        createElement('h3', {
            text: 'Biztosan törölni szeretné a profilját?',
            styles: {
                color: 'red',
                marginBottom: '10px'
            }
        }),
        createElement('p', {
            styles: {
                marginBottom: '15px'
            }
        },
            textNode('Ez a művelet '),
            createElement('b', { text: 'nem vonható vissza' }),
            textNode('!')
        )
    );

    if (data.isOnlyUser) {
        const onlyUserWarning = createWarningBox('red', 'rgba(255,0,0,0.1)');
        onlyUserWarning.append(
            createElement('b', { text: 'FIGYELEM:' }),
            textNode(' Ön az egyetlen regisztrált felhasználó az intézményben! A fiók törlésével a teljes intézményi adatbázis hozzáférhetetlenné válik.')
        );
        content.appendChild(onlyUserWarning);
    } else if (data.roleId === 2 && Array.isArray(data.soleRolesInModules) && data.soleRolesInModules.length > 0) {
        const analystWarning = createWarningBox('orange', 'rgba(255,165,0,0.2)');
        const moduleNames = data.soleRolesInModules
            .map(module => module.leiras || module.nev || 'Ismeretlen modul')
            .join(', ');

        analystWarning.append(
            createElement('b', { text: 'FIGYELEM:' }),
            textNode(' Ön az egyetlen Elemző az alábbi modul(ok)ban: '),
            createElement('b', { text: moduleNames }),
            textNode('. Kérjük a törlés után jelezze ezt az Adminnak.')
        );

        content.appendChild(analystWarning);
    }

    if (Array.isArray(data.sharedUsers) && data.sharedUsers.length > 0) {
        content.appendChild(createSharedUsersWarning(data.sharedUsers));
    }

    const buttonContainer = createElement('div', {
        id: 'alertDeleteButtons',
        styles: {
            marginTop: '20px',
            display: 'flex',
            flexDirection: 'column',
            gap: '10px'
        }
    });

    const confirmButton = createElement('button', {
        id: 'btnMegertettem',
        text: 'Megértettem, mindenképp törlöm a fiókot',
        styles: {
            backgroundColor: 'red',
            color: 'white',
            padding: '12px',
            border: 'none',
            cursor: 'pointer',
            borderRadius: '5px',
            fontWeight: 'bold',
            fontSize: '1rem',
            transition: '0.3s'
        }
    });

    const cancelButton = createElement('button', {
        id: 'btnMegsem',
        text: 'Mégsem',
        styles: {
            backgroundColor: '#555',
            color: 'white',
            padding: '12px',
            border: 'none',
            cursor: 'pointer',
            borderRadius: '5px',
            fontWeight: 'bold',
            fontSize: '1rem',
            transition: '0.3s'
        }
    });

    cancelButton.addEventListener('click', () => overlay.remove());

    confirmButton.addEventListener('click', async () => {
        confirmButton.disabled = true;
        confirmButton.textContent = 'Törlés folyamatban...';
        confirmButton.style.backgroundColor = 'gray';
        cancelButton.style.display = 'none';

        try {
            const delRes = await fetch('/api/delete-my-account', { method: 'DELETE' });
            const delData = await delRes.json();

            if (delData.success) {
                clearAndAppend(buttonContainer,
                    createElement('p', {
                        text: 'Fiókja és minden adata sikeresen törölve. Kijelentkezés...',
                        styles: {
                            color: 'green',
                            fontWeight: 'bold',
                            fontSize: '1.1rem',
                            padding: '10px'
                        }
                    })
                );

                setTimeout(() => {
                    window.location.href = '/index.html';
                }, 3000);
            } else {
                showAlert('Hiba történt a törlés során!');
                confirmButton.disabled = false;
                confirmButton.textContent = 'Megértettem, mindenképp törlöm a fiókot';
                confirmButton.style.backgroundColor = 'red';
                cancelButton.style.display = 'block';
            }
        } catch (error) {
            console.error('Hálózati hiba történt a törléskor.');
            showAlert('Hálózati hiba történt a törléskor.');
            confirmButton.disabled = false;
            confirmButton.textContent = 'Megértettem, mindenképp törlöm a fiókot';
            confirmButton.style.backgroundColor = 'red';
            cancelButton.style.display = 'block';
        }
    });

    buttonContainer.append(confirmButton, cancelButton);
    content.appendChild(buttonContainer);

    modalBox.appendChild(content);
    overlay.appendChild(modalBox);
    document.body.appendChild(overlay);
}

function createTestModalContent(isExt) {
    const container = createElement('div', { className: 'modal-container' });
    const license = window.__licenseStatus || {};
const isLicenseExpired =
    license.status === 'trial_expired' ||
    license.status === 'demo_expired' ||
    license.status === 'demo_limit_reached' ||
    license.status === 'expired';
    container.append(
        createElement('div', { className: 'modal-icon-wrapper' },
            createElement('span', {
                className: 'material-symbols-rounded icon-orange',
                text: isExt ? 'lock' : 'volunteer_activism'
            })
        ),
        createElement('h2', {
            className: 'modal-title',
            text: isLicenseExpired ? 'A próbaidő lejárt' : (isExt ? 'A tesztidőszak véget ért!' : 'Elérte a tesztelési limitet!')
        }),
        createElement('p', {
            className: 'modal-text',
            text: license.message || 'A próbaidő vagy a létrehozható értékelések kerete lejárt.'
        }),
        createElement('p', {
            className: 'modal-text',
            text: 'A meglévő értékeléseit továbbra is megnézheti és PDF-be mentheti, de új értékelés, szerkesztés, másolás, törlés és megosztás csak aktiválás után érhető el.'
        })
    );

    if (!isExt) {
        container.append(
            createElement('p', {
                className: 'modal-subtext',
                text: 'A folytatáshoz válasszon csomagot, vagy jelezze a kapcsolattartó felé, hogy kéri az élesítést.'
            }),
            createElement('div', { className: 'modal-info-box' },
                createElement('b', { text: 'Továbbhasználat:' }),
                createElement('p', {},
                    textNode('A csomag kiválasztása után a rendszerüzemeltető a szerződés és a fizetés beérkezése után aktiválja az intézményt.')
                )
            )
        );

        const actions = createElement('div', { className: 'modal-actions' },
            createElement('button', {
                id: 'btnAraink',
                className: 'btn4 btn-primary'
            },
                createElement('span', {
                    className: 'material-symbols-rounded',
                    text: 'shopping_cart'
                }),
                textNode(' Csomagajánlatok')
            ),
            createElement('button', {
                id: 'btnModalZar',
                className: 'btn4 btn-secondary',
                text: 'Bezárás'
            })
        );

        container.appendChild(actions);
        return container;
    }

    container.append(
        createElement('div', { className: 'modal-info-box' },
            createElement('p', {
                text: 'A rendszer további használati feltételeiről hamarosan e-mailben tájékoztatjuk.'
            }),
            createElement('p', {
                text: 'Köszönjük, hogy részt vett a tesztelési időszakban! Tapasztalatai felbecsülhetetlenek számunkra!'
            })
        ),
        createElement('div', { className: 'modal-actions' },
            createElement('button', {
                id: 'btnModalZar',
                className: 'btn4 btn-secondary',
                text: 'Bezárás',
                styles: {
                    width: 'fit-content',
                    background: 'orange'
                }
            })
        )
    );

    return container;
}

function formatLogDate(value) {
    if (!value || typeof value !== 'string' || !value.includes('T')) {
        return value || '';
    }

    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return value;

    return d.getFullYear() + '-' +
        String(d.getMonth() + 1).padStart(2, '0') + '-' +
        String(d.getDate()).padStart(2, '0') + ' ' +
        String(d.getHours()).padStart(2, '0') + ':' +
        String(d.getMinutes()).padStart(2, '0');
}

function renderEmptyState(container, message, color = 'gray') {
    clearAndAppend(container,
        createElement('div', {
            text: message,
            styles: { color }
        })
    );
}

export function playIntroSequence() {
    const pairs = [
        ['.analysis', '.growth2'],
        ['.growth', '.goals2'],
        ['.goals', '.dashboards2'],
        ['.dashboards']
    ];

    let delay = 0;
    const interval = 1500;

    pairs.forEach((pair, index) => {
        setTimeout(() => {
            pair.forEach(selector => {
                const card = document.querySelector(selector);
                if (card) {
                    card.classList.add('simulated-hover');
                }
            });

            if (index === pairs.length - 1) {
                setTimeout(() => {
                    document.querySelectorAll('.simulated-hover').forEach(card => {
                        card.classList.remove('simulated-hover');
                    });
                }, 2000);
            }

        }, delay);
        delay += interval;
    });
}

const infoPanelekTartalma = {
    changepass: {
        title: 'Jelszó Megváltoztatása'
    },
    remove: {
        title: 'Hozzájárulás Visszavonása'
    },
    plussj: {
        title: 'Jogosultságok Bővítése'
    },
    deleteacc: {
        title: 'Profil Törlése'
    }
};

export async function fetchAccountDeletionInfo(infoPanel) {
    try {
        const response = await fetch('/api/delete-account-info');
        const data = await response.json();

        if (infoPanel) {
            infoPanel.classList.remove('aktivp');
            setTimeout(() => infoPanel.remove(), 300);
        }

        if (!data.success) {
            showAlert('Hiba történt az adatok lekérésekor.');
            return;
        }

        if (
            data.roleId === 1 &&
            !data.isOnlyUser &&
            Array.isArray(data.soleRolesInModules) &&
            data.soleRolesInModules.length > 0
        ) {
            createBlockingAdminModal(data.soleRolesInModules);
            return;
        }

        createDeleteWarningModal(data);
    } catch (error) {
        console.error('Hálózati hiba történt a törlés ellenőrzésekor.');
        showAlert('Hálózati hiba történt a törlés ellenőrzésekor.');
    }
}

export function setupAccountInfoListeners(mainElement, userName) {
    const elsoDiv = mainElement.querySelector('.elso');
    const infoCards = mainElement.querySelectorAll('.infocard');

    if (!elsoDiv || infoCards.length === 0) return;

    infoCards.forEach(card => {
        card.addEventListener('click', function() {
            const cardId = this.id;
            const tartalom = infoPanelekTartalma[cardId];

            const letezikPanel = elsoDiv.querySelector('.info-panel');
            if (letezikPanel) {
                letezikPanel.remove();
            }

            if (tartalom) {
                const infoPanel = createElement('div', { className: 'info-panel' });

                const closeButton = createElement('span', {
                    className: 'bezaras',
                    text: '×'
                });

                const title = createElement('h3', { text: tartalom.title });
                const content = createElement('div');
                content.appendChild(createInfoPanelContent(cardId));

                infoPanel.append(closeButton, title, content);
                elsoDiv.appendChild(infoPanel);

                if (cardId === 'changepass') {
                    addPasswordValidationLogic(infoPanel, userName);
                }

                if (cardId === 'deleteacc') {
                    fetchAccountDeletionInfo(infoPanel);
                }

                setTimeout(() => {
                    infoPanel.classList.add('aktivp');
                }, 10);

                closeButton.addEventListener('click', () => {
                    infoPanel.classList.remove('aktivp');
                    infoPanel.addEventListener('transitionend', () => {
                        infoPanel.remove();
                    }, { once: true });
                });
            }
        });
    });
}



const PACKAGE_BILLING_LABELS = {
    monthly: { suffix: '/ hó', hint: 'Bruttó, havi díjak.', note: 'Havi fizetés' },
    quarterly: { suffix: '/ negyedév', hint: 'Bruttó, negyedéves díjak.', note: '3 havi díj egyben' },
    yearly: { suffix: '/ év', hint: 'Bruttó, éves díjak.', note: 'Éves fizetés, kedvezményesebb díjjal' }
};

const PACKAGE_UPGRADE_LABELS = {
    start: 'Start csomagváltást kérek',
    pro: 'Pro csomagváltást kérek',
    sajat: 'Saját rendszerre váltok',
    fenntartoi: 'Fenntartói csomagot kérek'
};

let packageUpgradeModalCsrfToken = '';
let packageUpgradeModalRequestInProgress = false;

function formatPackagePrice(value) {
    const n = Number(value || 0);
    return new Intl.NumberFormat('hu-HU').format(n) + ' Ft';
}

function packageRegisterBillingValue(period) {
    const map = {
        monthly: 'havi',
        quarterly: 'negyedeves',
        yearly: 'eves'
    };
    return map[period] || 'havi';
}

function escapePackageHTML(value) {
    return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}

function normalizePackageCodeForModal(value) {
    return String(value || '').trim().toLowerCase();
}

function ensurePackageUpgradeModalStyles() {
    if (document.getElementById('package-upgrade-modal-styles')) return;

    const style = document.createElement('style');
    style.id = 'package-upgrade-modal-styles';
    style.textContent = `
        .package-upgrade-modal {
            position: fixed;
            inset: 0;
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 18px;
            background: rgba(17, 24, 39, .72);
            backdrop-filter: blur(5px);
        }

        .package-upgrade-modal-box {
            position: relative;
            width: min(1180px, calc(100vw - 28px));
            max-height: min(88vh, 920px);
            overflow: auto;
            border-radius: 26px;
            background: rgba(255, 255, 255, .98);
            border: 1px solid rgba(255, 101, 0, .22);
            box-shadow: 0 24px 80px rgba(0, 0, 0, .36);
            color: #273142;
            font-family: Arial, sans-serif;
        }

        .package-upgrade-modal-head {
            position: sticky;
            top: 0;
            z-index: 5;
            display: flex;
            justify-content: space-between;
            gap: 14px;
            align-items: flex-start;
            padding: 22px 26px;
            background: linear-gradient(135deg, #fff7ed, #ffffff);
            border-bottom: 1px solid #fed7aa;
        }

        .package-upgrade-modal-head h2 {
            margin: 0;
            color: #ff6500;
            font-size: 1.45rem;
        }

        .package-upgrade-modal-head p {
            margin: 8px 0 0;
            color: #667085;
            line-height: 1.45;
        }

        .package-upgrade-modal-close {
            border: none;
            background: #fff;
            color: #9a3412;
            border-radius: 999px;
            width: 42px;
            height: 42px;
            font-size: 25px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(255, 101, 0, .16);
        }

        .package-upgrade-modal-body {
            padding: 24px 26px 28px;
        }

        .package-upgrade-loading,
        .package-upgrade-error {
            padding: 28px;
            border-radius: 20px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            color: #7c2d12;
            font-weight: 700;
            line-height: 1.55;
        }

        .package-upgrade-modal .pricing-section {
            padding: 0;
        }

        .package-upgrade-modal .section-head {
            display: flex;
            gap: 16px;
            align-items: flex-start;
            margin-bottom: 20px;
        }

        .package-upgrade-modal .section-step {
            flex: 0 0 auto;
            display: inline-grid;
            place-items: center;
            width: 48px;
            height: 48px;
            border-radius: 16px;
            background: #ff6500;
            color: #fff;
            font-weight: 900;
        }

        .package-upgrade-modal .hatos {
            display: flex;
            gap: 18px;
            align-items: stretch;
            width: 100%;
        }

        .package-upgrade-modal .hatdiv {
            flex: 1 1 auto;
        }

        .package-upgrade-modal .section-head h2 {
            margin: 0 0 7px;
            color: #273142;
            font-size: 1.45rem;
        }

        .package-upgrade-modal .section-head p {
            margin: 0;
            color: #667085;
            line-height: 1.5;
        }

        .package-upgrade-modal .billing-switch {
            flex: 0 0 360px;
            padding: 16px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 20px;
        }

        .package-upgrade-modal .billing-switch-title {
            font-weight: 900;
            color: #9a3412;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .package-upgrade-modal .billing-options {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }

        .package-upgrade-modal .billing-options button {
            border: 1px solid #fdba74;
            background: #fff;
            color: #9a3412;
            width: 100%;
            border-radius: 999px;
            padding: 11px 9px;
            cursor: pointer;
            font-weight: 900;
        }

        .package-upgrade-modal .billing-options button.active {
            background: #ff6500;
            color: #fff;
            border-color: #ff6500;
            box-shadow: 0 10px 24px rgba(255, 101, 0, .22);
        }

        .package-upgrade-modal .billing-hint {
            margin-top: 9px;
            color: #7c2d12;
            font-size: .9rem;
            font-weight: 700;
        }

        .package-upgrade-modal .pricing-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 16px;
        }

        .package-upgrade-modal .pricing-card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-height: 100%;
            padding: 20px;
            border-radius: 22px;
            background: #fff;
            border: 1px solid #fed7aa;
            box-shadow: 0 12px 28px rgba(0, 0, 0, .08);
        }

        .package-upgrade-modal .pricing-card.featured {
            border: 2px solid #ff6500;
            box-shadow: 0 18px 38px rgba(255, 101, 0, .16);
        }

        .package-upgrade-modal .pricing-card.current-package {
            outline: 3px solid rgba(255, 101, 0, .28);
            background: linear-gradient(180deg, #fff7ed 0%, #ffffff 44%);
        }

        .package-upgrade-modal .badge,
        .package-upgrade-modal .current-package-badge {
            display: inline-flex;
            width: fit-content;
            align-items: center;
            gap: 6px;
            border-radius: 999px;
            padding: 6px 10px;
            font-size: .78rem;
            font-weight: 900;
            margin-bottom: 10px;
        }

        .package-upgrade-modal .badge {
            background: #ff6500;
            color: #fff;
        }

        .package-upgrade-modal .current-package-badge {
            background: #7c2d12;
            color: #fff;
        }

        .package-upgrade-modal .pricing-card h2 {
            margin: 0 0 14px;
            color: #273142;
            font-size: 1.18rem;
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .package-upgrade-modal .price {
            color: #ff6500;
            font-size: 1.55rem;
            font-weight: 900;
            margin-bottom: 4px;
        }

        .package-upgrade-modal .price small {
            color: #667085;
            font-size: .85rem;
            font-weight: 700;
        }

        .package-upgrade-modal .billing-note,
        .package-upgrade-modal .package-small-title {
            color: #667085;
            font-size: .9rem;
        }

        .package-upgrade-modal .package-role {
            margin: 16px 0;
            padding: 13px;
            border-radius: 16px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            line-height: 1.45;
        }

        .package-upgrade-modal .pricing-card ul {
            padding-left: 20px;
            margin: 0 0 18px;
            color: #4b5563;
            line-height: 1.45;
        }

        .package-upgrade-modal .pricing-card li {
            margin-bottom: 7px;
        }

        .package-upgrade-modal .pricing-card a,
        .package-upgrade-modal .pricing-card button.package-upgrade-action {
            margin-top: auto;
            display: block;
            width: 100%;
            border: none;
            border-radius: 999px;
            padding: 12px 14px;
            background: #9a3412;
            color: #fff;
            text-align: center;
            text-decoration: none;
            font-weight: 900;
            cursor: pointer;
        }

        .package-upgrade-modal .pricing-card a.is-disabled,
        .package-upgrade-modal .pricing-card button.package-upgrade-action:disabled {
            background: #f3f4f6;
            color: #9ca3af;
            border: 1px solid #e5e7eb;
            cursor: not-allowed;
        }

        .package-upgrade-modal .note {
            margin-top: 20px;
            padding: 14px 16px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 18px;
            color: #7c2d12;
            line-height: 1.5;
        }

        @media (max-width: 1040px) {
            .package-upgrade-modal .pricing-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .package-upgrade-modal .hatos {
                flex-direction: column;
            }

            .package-upgrade-modal .billing-switch {
                flex-basis: auto;
            }
        }

        @media (max-width: 640px) {
            .package-upgrade-modal {
                padding: 10px;
                align-items: stretch;
            }

            .package-upgrade-modal-box {
                max-height: calc(100vh - 20px);
                width: 100%;
            }

            .package-upgrade-modal-head,
            .package-upgrade-modal-body {
                padding: 18px;
            }

            .package-upgrade-modal .section-head {
                flex-direction: column;
            }

            .package-upgrade-modal .pricing-grid,
            .package-upgrade-modal .billing-options {
                grid-template-columns: 1fr;
            }
        }
    `;
    document.head.appendChild(style);
}

function renderPackageModalPrices(scope, period) {
    const label = PACKAGE_BILLING_LABELS[period] || PACKAGE_BILLING_LABELS.monthly;

    scope.querySelectorAll('.pricing-card[data-package]').forEach(card => {
        const priceEl = card.querySelector('[data-price]');
        const noteEl = card.querySelector('[data-note]');
        if (!priceEl || !noteEl) return;

        if (card.dataset.package === 'demo') {
            priceEl.textContent = '0 Ft';
            noteEl.textContent = '3 napos kipróbálás';
            return;
        }

        const price = Number(card.dataset[period] || 0);
        priceEl.innerHTML = `${formatPackagePrice(price)} <small>${label.suffix}</small>${card.dataset.from === '1' ? ' <small>-tól</small>' : ''}`;
        noteEl.textContent = label.note;
    });

    const hint = scope.querySelector('#billingHint, .billing-hint');
    if (hint) hint.textContent = label.hint;
}

async function loadPackageUpgradeCsrfToken() {
    if (packageUpgradeModalCsrfToken) return packageUpgradeModalCsrfToken;

    try {
        const response = await fetch('/api/csrf-token', {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        });

        if (!response.ok) return '';
        const data = await response.json();
        packageUpgradeModalCsrfToken = data && data.success && data.csrfToken ? data.csrfToken : '';
        return packageUpgradeModalCsrfToken;
    } catch (err) {
        return '';
    }
}

function showPackageUpgradeStatus(modalBody, title, message, success = false) {
    clearAndAppend(
        modalBody,
        createElement('div', { className: success ? 'package-upgrade-loading' : 'package-upgrade-error' },
            createElement('h3', {
                text: title,
                styles: {
                    margin: '0 0 8px',
                    color: success ? '#166534' : '#7c2d12'
                }
            }),
            createElement('p', {
                styles: { margin: '0', color: success ? '#166534' : '#7c2d12' }
            }, createSafePackageMessage(message))
        )
    );
}

function createSafePackageMessage(message) {
    const fragment = document.createDocumentFragment();
    const template = document.createElement('template');
    template.innerHTML = String(message || '');

    const allowedTags = new Set(['strong', 'b', 'br']);
    const sanitize = node => {
        if (node.nodeType === Node.TEXT_NODE) return document.createTextNode(node.textContent || '');
        if (node.nodeType !== Node.ELEMENT_NODE) return document.createDocumentFragment();

        const tag = node.tagName.toLowerCase();
        if (!allowedTags.has(tag)) {
            const nested = document.createDocumentFragment();
            node.childNodes.forEach(child => nested.appendChild(sanitize(child)));
            return nested;
        }

        const el = document.createElement(tag);
        node.childNodes.forEach(child => el.appendChild(sanitize(child)));
        return el;
    };

    template.content.childNodes.forEach(node => fragment.appendChild(sanitize(node)));
    return fragment;
}

async function sendPackageUpgradeRequest(packageCode, billingPeriod, modalBody) {
    const normalizedCode = normalizePackageCodeForModal(packageCode);
    if (!normalizedCode || packageUpgradeModalRequestInProgress) return;

    const license = window.__licenseStatus || {};
    const currentCode = normalizePackageCodeForModal(license.packageCode || license.csomagKod || license.csomag_kod);

    if (normalizedCode === 'demo') {
        showPackageUpgradeStatus(
            modalBody,
            'Demo csak új regisztrációhoz',
            'Már meglévő intézménynél a Demo nem csomagváltási cél. Start, Pro vagy Saját rendszer csomag kérhető.'
        );
        return;
    }

    if (currentCode && normalizedCode === currentCode) {
        showPackageUpgradeStatus(
            modalBody,
            'Ez a jelenlegi csomag',
            'Ehhez a csomaghoz már tartozik aktív vagy folyamatban lévő hozzáférés.'
        );
        return;
    }

    packageUpgradeModalRequestInProgress = true;
    showPackageUpgradeStatus(modalBody, 'Kérelem küldése', 'A csomagváltási kérelem rögzítése folyamatban van…', true);

    try {
        const csrfToken = await loadPackageUpgradeCsrfToken();
        if (!csrfToken) {
            showPackageUpgradeStatus(
                modalBody,
                'Bejelentkezés szükséges',
                'A csomagváltási kérelemhez aktív bejelentkezés szükséges.'
            );
            return;
        }

        const response = await fetch('/api/package-change-request', {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                csomagKod: normalizedCode,
                fizetesiIdoszak: packageRegisterBillingValue(billingPeriod),
                extraFelhasznalo: 0,
                megjegyzes: 'Dashboard modalból indított csomagváltási kérelem.'
            })
        });

        const data = await response.json().catch(() => ({}));

        if (!response.ok || !data.success) {
            showPackageUpgradeStatus(
                modalBody,
                'Nem sikerült rögzíteni',
                escapePackageHTML(data.message || 'A csomagváltási kérelem rögzítése sikertelen.')
            );
            return;
        }

        showPackageUpgradeStatus(
            modalBody,
            'Csomagváltási kérelem rögzítve',
            `A kért csomag: <strong>${escapePackageHTML(data.packageName || normalizedCode)}</strong><br>` +
            `Várható összeg: <strong>${escapePackageHTML(formatPackagePrice(data.fizetendoOsszeg || 0))}</strong><br>` +
            escapePackageHTML(data.message || 'Az aktív csomag az üzemeltetői aktiválás után változik meg.'),
            true
        );
    } catch (err) {
        showPackageUpgradeStatus(modalBody, 'Hálózati hiba', 'A csomagváltási kérelem elküldése nem sikerült.');
    } finally {
        packageUpgradeModalRequestInProgress = false;
    }
}

function preparePackageUpgradeFragment(fragment, modalBody) {
    const license = window.__licenseStatus || {};
    const currentCode = normalizePackageCodeForModal(license.packageCode || license.csomagKod || license.csomag_kod);
    const currentName = license.packageName || license.csomagNev || '';
    let modalBillingPeriod = 'monthly';

    fragment.querySelectorAll('[id]').forEach(el => {
        el.id = `modal-${el.id}`;
    });

    fragment.querySelectorAll('.pricing-card[data-package]').forEach(card => {
        const packageCode = normalizePackageCodeForModal(card.dataset.package);
        const action = card.querySelector('a');

        if (packageCode && currentCode && packageCode === currentCode) {
            card.classList.add('current-package');
            const badge = createElement('span', {
                className: 'current-package-badge',
                text: currentName ? `Jelenlegi csomag: ${currentName}` : 'Jelenlegi csomag'
            });
            card.insertBefore(badge, card.firstChild);
        }

        if (action) {
            action.href = '#csomagvaltas';
            action.dataset.packageCode = packageCode;

            if (packageCode === 'demo') {
                action.textContent = packageCode === currentCode ? 'Jelenlegi demó' : 'Demo csak új regisztrációnál';
                action.classList.add('is-disabled');
            } else if (packageCode === currentCode) {
                action.textContent = 'Jelenlegi csomag';
                action.classList.add('is-disabled');
            } else {
                action.textContent = PACKAGE_UPGRADE_LABELS[packageCode] || 'Csomagváltást kérek';
            }

            action.addEventListener('click', event => {
                event.preventDefault();
                if (action.classList.contains('is-disabled')) {
                    sendPackageUpgradeRequest(packageCode, modalBillingPeriod, modalBody);
                    return;
                }
                sendPackageUpgradeRequest(packageCode, modalBillingPeriod, modalBody);
            });
        }
    });

    fragment.querySelectorAll('.billing-options button').forEach(button => {
        button.addEventListener('click', () => {
            const period = button.dataset.billing || 'monthly';
            modalBillingPeriod = period;
            fragment.querySelectorAll('.billing-options button').forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            renderPackageModalPrices(fragment, period);
        });
    });

    renderPackageModalPrices(fragment, modalBillingPeriod);
    return fragment;
}

function buildFallbackPackageSection() {
    const section = createElement('section', { className: 'pricing-section' });
    section.innerHTML = `
        <div class="section-head">
            <span class="section-step">02</span>
            <div class="hatos">
                <div class="hatdiv">
                    <h2>Csomagok</h2>
                    <p>Nem sikerült az árak oldal csomagrészletét betölteni, ezért a beépített csomagkártyák jelennek meg.</p>
                </div>
                <div class="billing-switch" aria-label="Fizetési időszak választása">
                    <div class="billing-switch-title">Fizetési időszak</div>
                    <div class="billing-options">
                        <button type="button" class="active" data-billing="monthly">Havi</button>
                        <button type="button" data-billing="quarterly">Negyedéves</button>
                        <button type="button" data-billing="yearly">Éves</button>
                    </div>
                    <div class="billing-hint">Bruttó, havi díjak.</div>
                </div>
            </div>
        </div>
        <div class="pricing-grid">
            <article class="pricing-card secondary" data-package="demo" data-monthly="0" data-quarterly="0" data-yearly="0">
                <h2>Demo</h2><div class="price" data-price>0 Ft</div><div class="billing-note" data-note>3 napos kipróbálás</div>
                <div class="package-role"><div class="package-small-title">Szerepkör</div><strong>1 értékelő</strong><br>Korlátozott próbahozzáférés.</div>
                <ul><li>3 napos próbaidőszak</li><li>3 létrehozható értékelés</li><li>PDF-mentés a meglévő értékelésekhez</li></ul>
                <a href="#csomagvaltas">Demo csak új regisztrációnál</a>
            </article>
            <article class="pricing-card featured" data-package="start" data-monthly="18900" data-quarterly="75000" data-yearly="222000">
                <span class="badge">Ajánlott indulásra</span><h2>Értékek Start</h2><div class="price" data-price></div><div class="billing-note" data-note></div>
                <div class="package-role"><div class="package-small-title">Szerepkör</div><strong>2 értékelő</strong><br>Teljes értékelői működés kisebb intézményi használatra.</div>
                <ul><li>korlátlan értékelés</li><li>teljes szakmai anyag</li><li>PDF, grafikon és AI-szövegezés</li></ul>
                <a href="#csomagvaltas">Start csomagváltást kérek</a>
            </article>
            <article class="pricing-card" data-package="pro" data-monthly="24900" data-quarterly="139000" data-yearly="279000">
                <h2>Értékek Pro</h2><div class="price" data-price></div><div class="billing-note" data-note></div>
                <div class="package-role"><div class="package-small-title">Szerepkörök</div><strong>3 értékelő + 2 elemző</strong><br>Intézményi és csoportos elemzéshez.</div>
                <ul><li>minden Start funkció</li><li>intézményi és csoportos statisztika</li><li>audit és megosztás</li></ul>
                <a href="#csomagvaltas">Pro csomagváltást kérek</a>
            </article>
            <article class="pricing-card secondary" data-package="sajat" data-monthly="19900" data-quarterly="79000" data-yearly="189000" data-from="1">
                <h2>Saját rendszer</h2><div class="price" data-price></div><div class="billing-note" data-note></div>
                <div class="package-role"><div class="package-small-title">Szerepkör</div><strong>3 feltöltő</strong><br>Saját szakmai anyag építéséhez.</div>
                <ul><li>üres értékelő rendszer</li><li>saját szakmai anyag feltöltése</li><li>feltöltői működés</li></ul>
                <a href="#csomagvaltas">Saját rendszerre váltok</a>
            </article>
        </div>
    `;
    return section;
}

async function loadPackagesSectionFromPricingPage() {
    const response = await fetch('/araink.html?modal=packages', {
        method: 'GET',
        credentials: 'same-origin',
        headers: { 'Accept': 'text/html' }
    });

    if (!response.ok) throw new Error('Az árak oldal nem tölthető be.');

    const html = await response.text();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const sections = Array.from(doc.querySelectorAll('.pricing-section'));
    const packagesSection = sections.find(section => {
        const step = (section.querySelector('.section-step')?.textContent || '').trim();
        const title = (section.querySelector('h2')?.textContent || '').trim().toLowerCase();
        return step === '02' || title.includes('csomagok');
    });

    if (!packagesSection) throw new Error('A csomagok blokk nem található.');

    return packagesSection.cloneNode(true);
}

async function openPackageUpgradeModal() {
    ensurePackageUpgradeModalStyles();

    if (window.loadLicenseStatus && (!window.__licenseStatus || !window.__licenseStatus.success)) {
        await window.loadLicenseStatus();
    }

    const old = document.getElementById('package-upgrade-modal');
    if (old) old.remove();

    const overlay = createElement('div', { id: 'package-upgrade-modal', className: 'package-upgrade-modal' });
    const box = createElement('div', { className: 'package-upgrade-modal-box' });
    const body = createElement('div', { className: 'package-upgrade-modal-body' });

    const closeButton = createElement('button', {
        className: 'package-upgrade-modal-close',
        text: '×',
        attrs: { type: 'button', title: 'Bezárás' }
    });

    closeButton.addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', event => {
        if (event.target === overlay) overlay.remove();
    });

    const license = window.__licenseStatus || {};
    const currentPackageText = license.packageName
        ? `Jelenlegi csomag: ${license.packageName}`
        : 'A jelenlegi csomagot a rendszer külön jelöli, ha be tudja azonosítani.';

    const head = createElement('div', { className: 'package-upgrade-modal-head' },
        createElement('div', {},
            createElement('h2', { text: 'Csomagváltás' }),
            createElement('p', { text: currentPackageText })
        ),
        closeButton
    );

    clearAndAppend(body, createElement('div', { className: 'package-upgrade-loading', text: 'Csomagok betöltése…' }));
    box.append(head, body);
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    try {
        const section = await loadPackagesSectionFromPricingPage();
        clearAndAppend(body, preparePackageUpgradeFragment(section, body));
    } catch (err) {
        const fallback = buildFallbackPackageSection();
        clearAndAppend(body, preparePackageUpgradeFragment(fallback, body));
    }
}

function openPackagePage() {
    openPackageUpgradeModal();
}

function formatRemainingDays(daysLeft) {
    if (daysLeft === null || daysLeft === undefined || Number.isNaN(Number(daysLeft))) return 'nincs adat';
    const n = Number(daysLeft);
    if (n <= 0) return 'ma jár le / lejárt';
    return `${n} nap`;
}

function renderLicenseFloatingPanel(license) {
    if (!license || !license.success) return;

const relevantStatuses = ['demo_active', 'demo_expired', 'demo_limit_reached', 'pending_activation', 'expired'];
    if (!relevantStatuses.includes(license.status)) return;

    const dismissedKey = `ertekek_license_panel_dismissed_${license.status}_${license.packageCode || 'default'}`;
    if (localStorage.getItem(dismissedKey) === '1') return;
    if (document.getElementById('license-floating-panel')) return;

    const used = Number(license.evaluationCount || 0);
    const limit = license.evaluationLimit === null || license.evaluationLimit === undefined ? null : Number(license.evaluationLimit);
    const remaining = limit === null ? `${used} létrehozott értékelés` : `${used} / ${limit} létrehozott értékelés`;
const expired = ['demo_expired', 'demo_limit_reached', 'expired'].includes(license.status);
    const pending = license.status === 'pending_activation';

    const panel = createElement('div', { id: 'license-floating-panel' });
    applyStyles(panel, {
        position: 'fixed',
        right: '22px',
        bottom: '22px',
        width: 'min(380px, calc(100vw - 44px))',
        background: '#fff7ed',
        border: '1px solid #fb923c',
        borderLeft: '7px solid #ff6500',
        borderRadius: '16px',
        boxShadow: '0 14px 34px rgba(0,0,0,0.24)',
        zIndex: '99999',
        padding: '16px',
        color: '#333',
        fontFamily: 'inherit'
    });

    const close = createElement('button', { text: '×', attrs: { type: 'button', title: 'Ne mutassa újra ezt az ablakot' } });
    applyStyles(close, {
        position: 'absolute',
        right: '10px',
        top: '8px',
        border: 'none',
        background: 'transparent',
        fontSize: '24px',
        cursor: 'pointer',
        color: '#9a3412'
    });
    close.addEventListener('click', () => {
        localStorage.setItem(dismissedKey, '1');
        panel.remove();
    });

    const title = createElement('div');
    applyStyles(title, { fontWeight: '800', fontSize: '1.05rem', marginRight: '22px', color: '#9a3412' });
title.textContent = pending
    ? 'A hozzáférés aktiválásra vár'
    : license.status === 'demo_limit_reached'
        ? 'A demó értékelésszám-kerete betelt'
        : expired
            ? 'A hozzáférés jelenleg korlátozott'
            : `${license.packageName || 'Demo'} hozzáférés aktív`;

    const text = createElement('div');
    applyStyles(text, { marginTop: '8px', lineHeight: '1.45', fontSize: '0.95rem' });
text.innerHTML = pending
    ? 'A regisztráció megtörtént, de a rendszer még nem aktív. A belépéshez szerződés, fizetés és sysadmin aktiválás szükséges.'
    : expired
        ? 'A létrehozott értékelések megtekinthetők és PDF-be menthetők. Új munka, szerkesztés, másolás, törlés és megosztás csak aktiválás után érhető el.'
        : `Hátralévő idő: <strong>${formatRemainingDays(license.daysLeft)}</strong><br>Értékelések: <strong>${remaining}</strong>`;
    const actions = createElement('div');
    applyStyles(actions, { display: 'flex', gap: '8px', marginTop: '12px', flexWrap: 'wrap' });

    const packageBtn = createElement('button', { text: 'Csomag választása', attrs: { type: 'button' } });
    applyStyles(packageBtn, {
        background: '#ff6500',
        color: '#fff',
        border: 'none',
        borderRadius: '999px',
        padding: '9px 14px',
        cursor: 'pointer',
        fontWeight: '700'
    });
    packageBtn.addEventListener('click', openPackagePage);

    const laterBtn = createElement('button', { text: 'Rendben', attrs: { type: 'button' } });
    applyStyles(laterBtn, {
        background: '#fff',
        color: '#9a3412',
        border: '1px solid #fdba74',
        borderRadius: '999px',
        padding: '9px 14px',
        cursor: 'pointer'
    });
    laterBtn.addEventListener('click', () => panel.remove());

    actions.append(packageBtn, laterBtn);
    panel.append(close, title, text, actions);
    document.body.appendChild(panel);
}

window.showLicenseToast = function(message) {
    const old = document.getElementById('license-toast');
    if (old) old.remove();

    const toast = createElement('div', { id: 'license-toast' });
    applyStyles(toast, {
        position: 'fixed',
        right: '22px',
        bottom: document.getElementById('license-floating-panel') ? '190px' : '22px',
        maxWidth: '360px',
        background: '#1f2937',
        color: '#fff',
        padding: '11px 14px',
        borderRadius: '12px',
        boxShadow: '0 10px 24px rgba(0,0,0,0.25)',
        zIndex: '100000',
        fontSize: '0.92rem',
        lineHeight: '1.35',
        opacity: '0',
        transform: 'translateY(8px)',
        transition: 'opacity .18s ease, transform .18s ease'
    });
    toast.textContent = message || 'Ez a művelet a jelenlegi csomagban nem érhető el.';
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    });
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(8px)';
        setTimeout(() => toast.remove(), 220);
    }, 3200);
};


window.__licenseStatus = null;

window.loadLicenseStatus = async function() {
    try {
        const response = await fetch('/api/license-status');
        const data = await response.json();
        if (data && data.success) {
            window.__licenseStatus = data;
            renderLicenseFloatingPanel(data);
            return data;
        }
    } catch (err) {
        console.error('Licencállapot betöltési hiba:', err);
    }
    return null;
};

window.mutasdPiackutatoAblakot = function(idoszak) {
    if (document.getElementById('teszt-modal')) return;

    const isExt = idoszak === 'teszt_ext';

    const overlay = createElement('div', { id: 'teszt-modal' });
    applyStyles(overlay, {
        position: 'fixed',
        top: '0',
        left: '0',
        width: '100vw',
        height: '100vh',
        backgroundColor: 'rgba(0,0,0,0.8)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: '999999',
        backdropFilter: 'blur(5px)',
        opacity: '0',
        transition: 'opacity 0.3s ease'
    });

    const modalBox = createElement('div');
    applyStyles(modalBox, {
        backgroundColor: '#fff',
        padding: '40px',
        borderRadius: '15px',
        maxWidth: '550px',
        width: '90%',
        boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
        transform: 'translateY(50px)',
        transition: 'transform 0.3s ease'
    });

    modalBox.appendChild(createTestModalContent(isExt));
    overlay.appendChild(modalBox);
    document.body.appendChild(overlay);

    setTimeout(() => {
        overlay.style.opacity = '1';
        modalBox.style.transform = 'translateY(0)';
    }, 10);

    document.getElementById('btnModalZar').addEventListener('click', () => {
        overlay.style.opacity = '0';
        modalBox.style.transform = 'translateY(50px)';
        setTimeout(() => overlay.remove(), 300);
    });

    const btnKardiov = document.getElementById('btnKardiov');
    if (btnKardiov) {
        btnKardiov.addEventListener('click', () => {
            window.location.href = '/private/kerdoiv.html';
        });
    }

    const btnAraink = document.getElementById('btnAraink');
    if (btnAraink) {
        btnAraink.addEventListener('click', openPackageUpgradeModal);
    }
};


window.isLicenseFeatureBlocked = function(featureOrAction) {
    const license = window.__licenseStatus;
    if (!license || !license.success || !license.permissions) return false;

    const action = String(featureOrAction || '');
    const map = {
        fo_edit: 'canEditEvaluation',
        edit: 'canEditEvaluation',
        save: 'canEditEvaluation',
        deleted: 'canDeleteEvaluation',
        delete: 'canDeleteEvaluation',
        duplicate: 'canDuplicateEvaluation',
        share: 'canShareEvaluation',
        generate_ai: 'canUseAi',
        audit: 'canUseAudit',
        group_stats: 'canUseGroupStatistics',
        groupStatistics: 'canUseGroupStatistics',
        csoportos_statisztika: 'canUseGroupStatistics',
        add: 'canCreateEvaluation',
        create: 'canCreateEvaluation'
    };

    const key = map[action] || Object.keys(map).find(k => action.includes(k));
    if (!key) return false;
    return license.permissions[key] === false;
};


window.canUseGroupStatistics = function() {
    const license = window.__licenseStatus;

    if (!license || !license.success || !license.permissions) {
        return true;
    }

    return license.permissions.canUseGroupStatistics !== false;
};

window.explainGroupStatisticsBlocked = function() {
    const license = window.__licenseStatus;
    const packageName = license?.packageName || 'jelenlegi csomag';

    if (packageName.toLowerCase().includes('start')) {
        return 'A csoportos statisztika és több értékelés kijelölése a Pro csomagban érhető el.';
    }

    return 'A csoportos statisztika a jelenlegi csomagban nem érhető el.';
};

window.isTesztLejart = function(idoszak, fizetve, int_fin, sajatLetrehozasuAdmin) {
    const license = window.__licenseStatus;
    if (license && license.success) {
        return ['demo_expired', 'expired', 'suspended', 'pending_activation'].includes(license.status);
    }

    if (idoszak !== 'teszt' && idoszak !== 'teszt_ext') return false;

    const maxErtekeles = idoszak === 'teszt' ? 2 : 4;
    let lejart = false;

    if (fizetve && int_fin) {
        const fizetesDatuma = new Date(fizetve);
        const ma = new Date();
        const lejaratDatuma = new Date(fizetesDatuma);
        lejaratDatuma.setDate(lejaratDatuma.getDate() + parseInt(int_fin, 10));

        const maNormalizalt = new Date(ma.getFullYear(), ma.getMonth(), ma.getDate());
        const lejaratNormalizalt = new Date(lejaratDatuma.getFullYear(), lejaratDatuma.getMonth(), lejaratDatuma.getDate());
        const idokulonbseg = lejaratNormalizalt.getTime() - maNormalizalt.getTime();
        const napokSzama = Math.ceil(idokulonbseg / (1000 * 3600 * 24));

        if (napokSzama < 0) lejart = true;
    }

    // v5: a létrehozott értékelések száma nem zárja le a próbát, csak a napalapú lejárat.

    return lejart;
};

export function ellenorizTesztStatusz(idoszak, fizetve, int_fin, sajatLetrehozasuAdmin) {
    if (window.isTesztLejart(idoszak, fizetve, int_fin, sajatLetrehozasuAdmin)) {
        window.mutasdPiackutatoAblakot(idoszak);
    }
}

export async function loadAdminLogs() {
    const sysContainer = document.getElementById('minden-log-container');
    const actContainer = document.getElementById('aktivitas-log-container');

    if (!sysContainer || !actContainer) return;

    try {
        const response = await fetch('/api/admin-logs');
        const data = await response.json();

        if (!data.success) {
            renderEmptyState(sysContainer, 'Hiba történt a logok betöltésekor.', 'red');
            renderEmptyState(actContainer, 'Hiba történt a logok betöltésekor.', 'red');
            return;
        }

        if (Array.isArray(data.systemLogs) && data.systemLogs.length > 0) {
            const systemItems = data.systemLogs.map(log => {
                const row = createElement('div', { className: 'logi' });
                const logText = String(log ?? '');
                const match = logText.match(/^\[(.*?)\]\s*\[.*?\]:\s*(.*)$/);

                if (match) {
                    const rawDate = match[1];
                    const message = match[2];
                    const formattedDate = formatLogDate(rawDate);

                    row.append(
                        createElement('span', {
                            text: formattedDate,
                            styles: {
                                color: '#ff6500',
                                fontWeight: 'bold',
                                fontStyle: 'italic'
                            }
                        }),
                        textNode(`: ${message}`)
                    );
                } else {
                    row.append(textNode(`- ${logText}`));
                }

                return row;
            });

            clearAndAppend(sysContainer, ...systemItems);
        } else {
            renderEmptyState(sysContainer, 'Nincs elérhető rendszer log.');
        }

        if (Array.isArray(data.activityLogs) && data.activityLogs.length > 0) {
            const activityItems = data.activityLogs.map(log => {
                const nev = log.vez || 'Ismeretlen felhasználó';
                const intezmeny = log.intnev || 'Ismeretlen intézmény';
                const akcio = log.tevekenyseg || 'Ismeretlen akció';
                const datumStr = formatLogDate(log.datum);

                return createElement('div', { className: 'log-sor' },
                    createElement('span', { className: 'log-jel', text: '-' }),
                    createElement('span', { className: 'log-nev', text: nev }),
                    createElement('span', { className: 'log-zaro', text: '(' }),
                    createElement('span', { className: 'log-intezmeny', text: intezmeny }),
                    createElement('span', { className: 'log-zaro', text: ')' }),
                    createElement('span', { className: 'log-valaszto', text: ':' }),
                    createElement('span', { className: 'log-akcio', text: akcio }),
                    createElement('span', { className: 'log-datum', text: datumStr })
                );
            });

            clearAndAppend(actContainer, ...activityItems);
        } else {
            renderEmptyState(actContainer, 'Nincs elérhető aktivitás log az adatbázisban.');
        }
    } catch (error) {
        console.error('Fetch hiba a logok lekérésekor.');
        renderEmptyState(sysContainer, 'Hálózati hiba.', 'red');
        renderEmptyState(actContainer, 'Hálózati hiba.', 'red');
    }
}
